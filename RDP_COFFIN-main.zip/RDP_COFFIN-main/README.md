# RDP_COFFIN
FREE RDP WINDOWS SERVER 2019


* Click Fork in the right corner of the screen to save it to your Github.
* Visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN
* In Github go to ⚙ Settings> Secrets> New repository secret
* In Name: enter NGROK_AUTH_TOKEN
* In Value: visit https://dashboard.ngrok.com/auth/your-authtoken Copy and Paste Your Authtoken into
* Press Add secret
* Go to Action> RDP_2019> Run workflow
* Reload the page and press RDP_2019> build
* Press the down arrow on Connect To Your RPD to get IP, User, Password.
* If you have any questions, contact me in Discord: vv#0999
